# ADC Process Audit

Version 1.0.0-rc1 · Research reproduction package

A portable, synthetic-only reproduction of the frozen four-b-value breast DWI ADC computation and its 21-case digital reference object (DRO) suite. It preserves zero-valued ROI voxels, makes units explicit, and tests technical rejection conditions. It does not establish patient ADC truth, clinical accuracy, general DICOM conformance, or improved repeatability.

**中文入口：[使用说明](docs/使用说明.md) · [数字参照目录](docs/数字参照目录.md) · [技术教训](docs/技术教训与适用边界.md)。**

## Quick start

Use Python 3.12; the original environment was Python 3.12.14. From this extracted directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run_dro.py --output out_dro
.venv/bin/python examples/synthetic_pipeline.py --output out_example
```

On Windows use `.venv\Scripts\python.exe` in place of `.venv/bin/python`. Only macOS/Python 3.12 has been tested for this release. Installation can require network access; the two programs themselves use no network and accept no patient input directory.

Expected DRO result: **21 cases, 299 assertions, all passed**; process exit 0. Examine `out_dro/results/summary.json` and `acceptance.tsv`, not only terminal text. Exit 1 means acceptance failure; exit 2 means a setup/integrity/output-path problem. Every output path must be new: an existing directory is refused rather than overwritten. A different installed NumPy/pydicom version is recorded as an environment deviation, even if assertions pass.

The example creates synthetic classic MR ADC, TRACE, sparse MASK and SEG objects, maps their coordinates, checks source references, fits ADC by two implementations, and writes `report.json` plus `synthetic_arrays.npz`. Its public ADC is constructed and is not an observation from the study.

## What is included

- `frozen/adc_core.py`: fixed public ADC scaling, geometry, four-b OLS, zero codes, ROI readout and limited source-reference checks.
- `frozen/reference_b.py`: independent least-squares calculation and classic MR TRACE decoder.
- `frozen/statistics_core.py`: original patient-equal estimator and fixed within-site bootstrap policy.
- `frozen/dro_generate.py`, `frozen/dro_suite.py`: unchanged synthetic fixture generator and 21 case definitions.
- `run_dro.py`: new portable execution adapter; no Git repository or original patient ledger is required.
- `examples/synthetic_pipeline.py`: small API demonstration using synthetic files only.
- `core_provenance.json`: hashes linking the five unchanged modules and original configurations to the study version.
- `evidence/`: portable replay acceptance evidence and package validation; no patient images or individual results.

The original `frozen/dro_suite.py` formal `main()` is retained for provenance and should **not** be used here. Run the portable adapter. The adapter invokes the same `Case` and case functions with a new output root; it does not bypass or edit the original study's run/recovery ledger. The original study configuration is an archived specification, not a user-tunable CLI configuration: core constants stay frozen and the DRO includes tests that detect relevant mismatches.

## Interpretation and reuse

DRO PASS means the specified calculation or expected failure response worked. A rejection-case PASS can mean the input was correctly held or stopped. It never means every generated image passed quantitative eligibility. The comparator uses public TRACE at b = 0, 100, 600, 800 s/mm² and is not the original vendor pipeline or true human ADC.

The study's fixed 30-patient attempt yielded 17 complete quantitative pairs, all GE; no inferential interval was reported because the frozen minimum was 24. A post-pixel TRACE reading clarification was disclosed. Those facts are context, not general performance claims for this package. Physician ROI agreement does not release source/RWVM/FTV holds.

Use the [API and units](docs/API与单位合同.md) to reuse individual functions. There is intentionally no new automatic clinical-data importer in this release. A new dataset needs its own explicit identity/source manifest and applicability assessment; this is outside the completed fixed-30 study, whose results remain unchanged.

## Attribution and release state

See [citation and data provenance](CITATION.md) and [licensing and distribution](docs/发布与许可说明.md). This is a local research release candidate; no GitHub/Zenodo upload, DOI assignment, public software license grant, or external publication has occurred. Source origin, rights and intended licensing should be finalized when a public release is chosen. It remains usable for local project reproduction.
