# Changelog

## 1.0.0-rc1 — 2026-09-24

- Copied five final production modules and two frozen configuration files byte-for-byte.
- Added a portable synthetic execution adapter without Git or patient-ledger dependencies.
- Added a synthetic classic-MR/SEG to fixed-ROI example, with A/B comparison.
- Documented API units, zero-code semantics, supported geometry, rejection semantics, known reference-classification limits, and the post-pixel TRACE clarification.
- Replayed all 21 cases and 299 assertions; preserved source and output provenance.
- No changes to scientific constants, patient roster, masks, original public ADC, clinical outcomes, technical holds, or the original one-recovery budget.

The historical original run had 288 assertions. The final post-repair D15 regression increased the total to 299; this occurred during the original study, not during packaging. The core source in this release is the final version.
