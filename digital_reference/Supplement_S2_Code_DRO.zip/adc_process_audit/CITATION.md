# Citation and provenance

Working software title: **ADC Process Audit: a fixed four-b-value ADC computation and digital reference reproduction package**.

Version: **1.0.0-rc1**. Local preparation date: **2026-09-24**.

- Frozen scientific protocol: `dd62919e2dee88a204294d354dd289fba33ee524`.
- Frozen production source: `72940cc3a7d829532161f3c7ed94edc719fa3ba0`.
- Exact copied modules and configurations: `core_provenance.json`.
- Portable adapter: newly written for this release; its execution hash is in the DRO summary.

This local package has no assigned DOI, published repository URL, finalized author list, or public software license. Do not invent these in a manuscript. After an authorized public release, replace this record with the actual repository/version/DOI and verified authorship metadata. No citation to an unreleased package should imply public availability.

Study data source (not redistributed in this package): The Cancer Imaging Archive, ACRIN-6698 collection, https://www.cancerimagingarchive.net/collection/acrin-6698/ . Cite the collection using the then-current TCIA recommended dataset citation when publishing an analysis; the URL here is a provenance pointer, not a fabricated dataset DOI.

Related primary research:

- Newitt DC, Zhang Z, Gibbs JE, et al. Test-retest repeatability and reproducibility of ADC measures by breast DWI: Results from the ACRIN 6698 trial. J Magn Reson Imaging. 2019;49(6):1617-1628. doi:10.1002/jmri.26539.
- Newitt DC, Malyarenko D, Chenevert TL, et al. Multisite concordance of apparent diffusion coefficient measurements across the NCI Quantitative Imaging Network. J Med Imaging (Bellingham). 2018;5(1):011003. doi:10.1117/1.JMI.5.1.011003.

The software and its synthetic fixtures do not inherit TCIA image licensing merely because TCIA data motivated the study. Third-party libraries remain under their own licenses and are installed as dependencies, not copied into this archive.
