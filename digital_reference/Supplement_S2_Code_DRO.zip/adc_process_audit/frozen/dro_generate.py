"""Deterministic synthetic-only DRO fixtures; never opens patient files."""
from pathlib import Path
import hashlib
import json
import uuid
import numpy as np
import pydicom
from pydicom.dataset import FileDataset, FileMetaDataset, Dataset
from pydicom.sequence import Sequence
from pydicom.uid import ExplicitVRLittleEndian, MRImageStorage, SegmentationStorage

NAMESPACE = uuid.UUID('ac669800-2026-5092-8000-000000000030')
BVALS = np.array([0., 100., 600., 800.])
SHAPE = (12, 16, 16)
AVALS = np.array([0, .0003, .0008, .0012, .0020, .0035])

def uid(case, role, b='', z='', variant='base'):
    return '2.25.' + str(uuid.uuid5(NAMESPACE, f'{case}/{role}/{b}/{z}/{variant}').int)

def orientation(angle=0):
    t = np.deg2rad(angle)
    return [float(np.cos(t)), float(np.sin(t)), 0., float(-np.sin(t)), float(np.cos(t)), 0.]

def positions():
    return np.array([[10., 20., float(5*z)] for z in range(12)])

def roi():
    out = np.zeros(SHAPE, dtype=np.uint16)
    out[3:9,4:12,4:12] = 1
    return out

def grid(s0s=(20,200,2000)):
    pairs = [(s,a) for s in s0s for a in AVALS]
    s0 = np.array([p[0] for p in pairs], dtype=float)
    a = np.array([p[1] for p in pairs], dtype=float)
    return s0[None,:] * np.exp(-BVALS[:,None]*a[None,:]), a

def signal_volume(a=.0012, s0=200):
    return np.broadcast_to((s0*np.exp(-BVALS*a))[:,None,None,None], (4,)+SHAPE).copy()

def quantize(signal, slopes, intercepts):
    rs = np.asarray(slopes).reshape((4,)+(1,)*(signal.ndim-1))
    ri = np.asarray(intercepts).reshape((4,)+(1,)*(signal.ndim-1))
    pixels = np.rint((signal-ri)/rs)
    if np.any(~np.isfinite(pixels)) or np.any(pixels < 0) or np.any(pixels > 65535):
        raise ValueError('DRO encoding overflow: clipping is prohibited')
    return pixels.astype(np.uint16)

def quantization_bound(signal, slopes):
    epsilon = np.asarray(slopes).reshape((4,)+(1,)*(signal.ndim-1))/2
    if not np.all(epsilon < signal):
        raise ValueError('quantization bound requires epsilon < physical signal')
    x = BVALS-BVALS.mean()
    return np.sum(np.abs(x).reshape((4,)+(1,)*(signal.ndim-1)) * -np.log1p(-epsilon/signal), axis=0)/np.sum(x*x) + 1e-12

def expected_identity(case, role):
    return {'patient_id':'SYNTHETIC_DRO', 'study_uid':uid(case,'study'),
            'series_uid':uid(case,role), 'visit':'T0'}

def base_dataset(case, role, b='', z=0, angle=0, variant='base', seg=False):
    sopclass = SegmentationStorage if seg else MRImageStorage
    meta = FileMetaDataset()
    meta.MediaStorageSOPClassUID = sopclass
    meta.MediaStorageSOPInstanceUID = uid(case,role,b,z,variant)
    meta.TransferSyntaxUID = ExplicitVRLittleEndian
    meta.ImplementationClassUID = uid('IMPLEMENTATION','DRO')
    ds = FileDataset(None, {}, file_meta=meta, preamble=b'\0'*128)
    ds.SOPClassUID = sopclass
    ds.SOPInstanceUID = meta.MediaStorageSOPInstanceUID
    ds.PatientName = 'SYNTHETIC^DRO'
    ds.PatientID = 'SYNTHETIC_DRO'
    ds.PatientBirthDate = ''
    ds.PatientSex = 'O'
    ds.StudyInstanceUID = uid(case,'study')
    ds.SeriesInstanceUID = uid(case,role)
    ds.FrameOfReferenceUID = uid(case,'FOR')
    ds.StudyID = 'DRO'
    ds.StudyDescription = 'T0'
    ds.ClinicalTrialTimePointID = 'T0'
    ds.AcquisitionTime = '120000'
    ds.StudyDate = '20260923'
    ds.StudyTime = '120000'
    ds.ContentDate = '20260923'
    ds.ContentTime = '120000'
    ds.SeriesNumber = {'ADC':1,'TRACE':2,'MASK':3,'SEG':4}.get(role,5)
    ds.SeriesDescription = role
    ds.Modality = 'SEG' if seg else 'MR'
    ds.InstanceNumber = z+1
    ds.ImageType = ['DERIVED','SECONDARY',role]
    ds.PatientPosition = 'HFS'
    ds.Manufacturer = 'SYNTHETIC_DRO'
    if not seg:
        ds.ScanningSequence = 'SE'
        ds.SequenceVariant = 'SK'
        ds.ScanOptions = ''
        ds.MRAcquisitionType = '2D'
        ds.RepetitionTime = 4000.
        ds.EchoTime = 80.
        ds.EchoTrainLength = 1
    ds.ImageOrientationPatient = orientation(angle)
    ds.ImagePositionPatient = positions()[z].tolist()
    ds.PixelSpacing = [1.25,1.25]
    ds.SliceThickness = 5.
    ds.SpacingBetweenSlices = 5.
    ds.Rows = 16
    ds.Columns = 16
    ds.SamplesPerPixel = 1
    ds.PhotometricInterpretation = 'MONOCHROME2'
    ds.BitsAllocated = 16
    ds.BitsStored = 16
    ds.HighBit = 15
    ds.PixelRepresentation = 0
    ds.RescaleSlope = 1.
    ds.RescaleIntercept = 0.
    if b != '':
        ds.DiffusionBValue = float(b)
        diff = Dataset(); diff.DiffusionBValue = float(b)
        diff.DiffusionDirectionality = 'ISOTROPIC'
        ds.MRDiffusionSequence = Sequence([diff])
    return ds

def volume(case, role='ADC', pixels=None, angle=0, sparse=False, rs=.001, ri=0., variant='base'):
    if pixels is None:
        pixels = np.full(SHAPE,1200,dtype=np.uint16)
    out=[]
    for z in (range(3,9) if sparse else range(12)):
        ds=base_dataset(case,role,z=z,angle=angle,variant=variant if angle==0 else f'{variant}_angle{angle}')
        ds.RescaleSlope = rs
        ds.RescaleIntercept = ri
        ds.RescaleType = '10^-3 mm2/s' if role == 'ADC' else 'US'
        ds.PixelData = np.asarray(pixels[z],dtype='<u2').tobytes()
        out.append(ds)
    return out

def trace(case, signal=None, slopes=(.01,)*4, intercepts=(0.,)*4, angle=0, variant='base'):
    if signal is None:
        signal=signal_volume()
    raw=quantize(signal,slopes,intercepts)
    out=[]
    for k,b in enumerate(BVALS):
        for z in range(12):
            ds=base_dataset(case,'TRACE',int(b),z,angle,variant)
            ds.RescaleSlope=float(slopes[k]); ds.RescaleIntercept=float(intercepts[k]); ds.RescaleType='US'
            ds.InstanceNumber = int(k*12+z+1)
            ds.PixelData=raw[k,z].astype('<u2').tobytes()
            out.append(ds)
    return out

def segmentation(case, angle=0):
    ds=base_dataset(case,'SEG',z=3,angle=angle,variant=f'angle{angle}',seg=True)
    ds.SegmentationType='FRACTIONAL'
    ds.SegmentationFractionalType='PROBABILITY'
    ds.MaximumFractionalValue=255
    ds.BitsAllocated=8; ds.BitsStored=8; ds.HighBit=7
    ds.NumberOfFrames=6
    ds.ContentLabel='SYNTHETIC_DRO'
    ds.ContentDescription='Synthetic sparse nonzero support test'
    ds.ContentCreatorName='SYNTHETIC^DRO'
    ds.SegmentsOverlap='NO'
    segment=Dataset(); segment.SegmentNumber=1; segment.SegmentLabel='DRO_ROI'
    segment.SegmentAlgorithmType='AUTOMATIC'; segment.SegmentAlgorithmName='Frozen geometric fixture'
    code=Dataset(); code.CodeValue='T-D0050'; code.CodingSchemeDesignator='SRT'; code.CodeMeaning='Tissue'
    segment.SegmentedPropertyCategoryCodeSequence=Sequence([code])
    segment.SegmentedPropertyTypeCodeSequence=Sequence([code])
    ds.SegmentSequence=Sequence([segment])
    shared=Dataset(); orient=Dataset(); orient.ImageOrientationPatient=orientation(angle)
    shared.PlaneOrientationSequence=Sequence([orient])
    measures=Dataset(); measures.PixelSpacing=[1.25,1.25]; measures.SliceThickness=5.; measures.SpacingBetweenSlices=5.
    shared.PixelMeasuresSequence=Sequence([measures])
    ds.SharedFunctionalGroupsSequence=Sequence([shared])
    frames=[]
    for z in range(3,9):
        fg=Dataset(); pos=Dataset(); pos.ImagePositionPatient=positions()[z].tolist()
        fg.PlanePositionSequence=Sequence([pos])
        ident=Dataset(); ident.ReferencedSegmentNumber=1
        fg.SegmentIdentificationSequence=Sequence([ident])
        content=Dataset(); content.DimensionIndexValues=[1,z+1]; content.StackID='1'; content.InStackPositionNumber=z+1
        fg.FrameContentSequence=Sequence([content]); frames.append(fg)
    ds.PerFrameFunctionalGroupsSequence=Sequence(frames)
    org=Dataset(); org.DimensionOrganizationUID=uid(case,'SEG_DIMENSION',variant=f'angle{angle}')
    ds.DimensionOrganizationSequence=Sequence([org])
    dim1=Dataset(); dim1.DimensionOrganizationUID=org.DimensionOrganizationUID
    dim1.DimensionIndexPointer=0x0062000B; dim1.FunctionalGroupPointer=0x0062000A
    dim2=Dataset(); dim2.DimensionOrganizationUID=org.DimensionOrganizationUID
    dim2.DimensionIndexPointer=0x00200032; dim2.FunctionalGroupPointer=0x00209113
    ds.DimensionIndexSequence=Sequence([dim1,dim2])
    ds.PixelData=roi()[3:9].astype(np.uint8).tobytes()
    return [ds]

class Fixtures:
    """Store each artifact once, reload it, and reject all subsequent changes."""
    def __init__(self, root, case):
        self.root=Path(root)/case; self.root.mkdir(parents=True,exist_ok=True)
        self.hashes={}
    def _record(self,path):
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        self.hashes[str(path.relative_to(self.root))]=digest
        path.chmod(0o444)
        return digest
    def arrays(self,name,**arrays):
        # NPY avoids ZIP container timestamps and allows deterministic per-array hashes.
        out={}
        for key,val in arrays.items():
            path=self.root/f'{name}_{key}.npy'
            arr=np.asarray(val)
            if path.exists():
                old=np.load(path,allow_pickle=False)
                if old.dtype != arr.dtype or old.shape != arr.shape or not np.array_equal(old,arr,equal_nan=True):
                    raise RuntimeError(f'Immutable DRO input mismatch: {path}')
            else:
                with path.open('xb') as f: np.save(f,arr,allow_pickle=False)
            self._record(path); out[key]=np.load(path,allow_pickle=False)
        return out
    def dicoms(self,name,datasets):
        from io import BytesIO
        directory=self.root/name; directory.mkdir(exist_ok=True)
        out=[]
        for i,ds in enumerate(datasets):
            path=directory/f'{i:04d}.dcm'
            buffer=BytesIO(); pydicom.dcmwrite(buffer,ds,enforce_file_format=True)
            data=buffer.getvalue()
            if path.exists():
                if path.read_bytes() != data: raise RuntimeError(f'Immutable DRO input mismatch: {path}')
            else:
                with path.open('xb') as f: f.write(data)
            self._record(path); out.append(pydicom.dcmread(path))
        return out
    def json(self,name,value):
        path=self.root/f'{name}.json'
        data=(json.dumps(value,sort_keys=True,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
        if path.exists():
            if path.read_bytes()!=data: raise RuntimeError(f'Immutable DRO input mismatch: {path}')
        else:
            with path.open('xb') as f: f.write(data)
        self._record(path)
        return json.loads(path.read_text())
    def finish(self):
        # The per-run case result is the immutable manifest, so a failed run
        # that halted a case early cannot overwrite a later run's manifest.
        return dict(self.hashes)
