#!/usr/bin/env python3
"""Frozen 21-case synthetic DRO acceptance runner. No patient or network I/O.

Run only after committing implementation: python src/dro_suite.py --run run01
A failed case never prevents subsequent cases from executing. Existing run names
are immutable. run02/run03 require the preceding failed run and a repair record.
"""
from pathlib import Path
from copy import deepcopy
import argparse
import datetime as dt
import hashlib
import json
import platform
import subprocess
import sys
import traceback
import numpy as np
import pydicom
from pydicom.dataset import Dataset
from pydicom.sequence import Sequence
import adc_core as A
import reference_b as B
import statistics_core as ST
import dro_generate as G

ROOT=Path(__file__).resolve().parents[1]
DRO=ROOT/'execution'/'dro'


def clean(value):
    if isinstance(value,np.ndarray): return clean(value.tolist())
    if isinstance(value,np.generic): return clean(value.item())
    if isinstance(value,float) and not np.isfinite(value): return str(value)
    if isinstance(value,dict): return {str(k):clean(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [clean(v) for v in value]
    return value


def write_json(path,value):
    with Path(path).open('x') as f:
        json.dump(clean(value),f,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)
        f.write('\n')
    Path(path).chmod(0o444)


class Case:
    def __init__(self,case,expected_root):
        self.id=case; self.fixtures=G.Fixtures(DRO/'inputs',case)
        self.expected_root=expected_root/case; self.expected_root.mkdir()
        self.assertions=[]; self.max_errors={}; self.expected_hashes={}; self.diagnostics={}
        self.fixtures.json('contract',{'case':case,'geometry_shape':G.SHAPE,'positions':G.positions().tolist(),
                    'roi_voxels':384,'b_values':G.BVALS.tolist(),'patient_id':'SYNTHETIC_DRO',
                    'uid_namespace':str(G.NAMESPACE),'numerical_zero':1e-12,'ab_tolerance':1e-10})
    def check(self,name,condition,actual=None,expected=None):
        self.assertions.append({'assertion':name,'pass':bool(condition),'actual':clean(actual),'expected':clean(expected)})
    def near(self,name,actual,expected,tol):
        aa=np.asarray(actual,dtype=float); ee=np.asarray(expected,dtype=float)
        err=float(np.max(np.abs(aa-ee))) if aa.size else 0.
        self.max_errors[name]=err
        self.check(name,np.isfinite(err) and err<=tol,{'max_absolute_error':err,'tolerance':tol},expected)
    def equal(self,name,actual,expected):
        aa=np.asarray(actual); ee=np.asarray(expected)
        def brief(x):
            return x if x.size<=64 else {'shape':list(x.shape),'dtype':str(x.dtype),'sha256':hashlib.sha256(x.tobytes()).hexdigest()}
        self.check(name,np.array_equal(aa,ee),brief(aa),brief(ee))
    def expect(self,name,fn,status='HOLD'):
        try:
            out=fn()
        except A.GateError as exc:
            self.check(name,exc.status==status,{'status':exc.status,'code':exc.code,'message':str(exc)},status)
        except Exception as exc:
            self.check(name,False,{'unexpected_exception':type(exc).__name__,'message':str(exc)},status)
        else:
            self.check(name,False,{'returned_value_instead_of_gate':clean(out)},status)
    def expected(self,name,**arrays):
        for key,arr in arrays.items():
            path=self.expected_root/f'{name}_{key}.npy'
            with path.open('xb') as f: np.save(f,np.asarray(arr),allow_pickle=False)
            path.chmod(0o444); self.expected_hashes[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
    def compare(self,name,signal,analytic=None,tol=1e-12):
        aa=A.fit(signal,G.BVALS); bb=B.fit(signal,G.BVALS)
        self.expected(name,B_adc=bb['adc'],B_reason=bb['reason'],B_high=bb['high'])
        valid=np.isfinite(aa['adc']) & np.isfinite(bb['adc'])
        self.equal(name+'_finite_support',np.isfinite(aa['adc']),np.isfinite(bb['adc']))
        self.near(name+'_A_B',aa['adc'][valid],bb['adc'][valid],1e-10)
        self.equal(name+'_reason',aa['reason'],bb['reason'])
        self.equal(name+'_high',aa['high'],bb['high'])
        if analytic is not None:
            self.expected(name,analytic=analytic)
            self.near(name+'_analytic',aa['adc'],analytic,tol)
        return aa,bb
    def dicoms(self,name,ds): return self.fixtures.dicoms(name,ds)
    def adc(self,name='adc',**kwargs):
        ds=self.dicoms(name,G.volume(self.id,**kwargs))
        return A.load_volume(ds,G.expected_identity(self.id,'ADC'),kind='ADC')
    def mask(self,name='mask',angle=0):
        ds=self.dicoms(name,G.volume(self.id,'MASK',G.roi(),angle=angle,sparse=True,rs=1))
        return A.load_volume(ds,G.expected_identity(self.id,'MASK'),kind='MASK')
    def traced(self,name='trace',reference=None,**kwargs):
        ds=self.dicoms(name,G.trace(self.id,**kwargs))
        out=A.trace_signal(ds,reference,G.expected_identity(self.id,'TRACE'))
        return ds,out


def d01(c):
    signal,analytic=G.grid(); x=c.fixtures.arrays('grid',signal=signal,analytic=analytic)
    out,_=c.compare('grid',x['signal'],x['analytic'])
    c.equal('zero_reason',out['reason'][x['analytic']==0],np.full(3,2))
    c.equal('positive_reason',out['reason'][x['analytic']>0],np.zeros(15,dtype=np.uint8))


def d02(c):
    signal,analytic=G.grid()
    x=c.fixtures.arrays('multiplicative',signal=signal,scales=[.1,1.,17.6351648352,100.])
    base=A.fit(x['signal'],G.BVALS)
    for i,scale in enumerate(x['scales']):
        out,_=c.compare(f'scale{i}',x['signal']*scale,analytic)
        c.near(f'invariance_{i}',out['adc'],base['adc'],1e-12)


def d03(c):
    signal,analytic=G.grid(); signal=c.fixtures.arrays('grid',signal=signal)['signal']
    c.compare('independent_solver',signal,analytic)
    c.check('different_solver_modules',A.fit.__module__ != B.fit.__module__,[A.fit.__module__,B.fit.__module__],'distinct')


def encoded(c,slopes,intercepts):
    grid,analytic=G.grid((20,200))
    # All twelve combinations occur on every slice, including inside the ROI.
    indexes=np.arange(np.prod(G.SHAPE)).reshape(G.SHAPE)%12
    signal=grid[:,indexes]; truth=analytic[indexes]
    arrays=c.fixtures.arrays('quantization',physical_truth=signal,analytic=truth,slopes=slopes,intercepts=intercepts,
                              quantization_bound=G.quantization_bound(signal,slopes),grid_combo_index=indexes)
    reference=c.adc(); ds,ta=c.traced(reference=reference,signal=arrays['physical_truth'],slopes=slopes,intercepts=intercepts)
    tb=B.from_datasets(ds)
    c.near('independent_DICOM_decoding',ta['signal'],tb['signal'],1e-12)
    # Independently decode the generated integer representation from specification.
    raw=G.quantize(signal,slopes,intercepts)
    decoded=raw*np.asarray(slopes)[:,None,None,None]+np.asarray(intercepts)[:,None,None,None]
    c.near('single_rescale_application',ta['signal'],decoded,1e-12)
    aa=A.fit(ta['signal'],G.BVALS); bb=B.fit(tb['signal'],G.BVALS)
    c.expected('encoded',B_adc=bb['adc'],analytic=truth,quantization_bound=arrays['quantization_bound'])
    c.near('encoded_A_B_ADC',aa['adc'],bb['adc'],1e-10)
    c.equal('encoded_A_B_reason',aa['reason'],bb['reason']); c.equal('encoded_A_B_high',aa['high'],bb['high'])
    error=np.abs(aa['adc']-truth); bound=arrays['quantization_bound']
    c.check('analytical_quantization_bound',np.all(error<=bound),{'max_error':float(error.max()),'max_bound_excess':float((error-bound).max())},'every voxel error <= independently calculated bound')
    c.max_errors['versus_unquantized_analytic']=float(error.max())
    mask=A.align(reference,c.mask())!=0
    c.equal('ROI_count',np.count_nonzero(mask),384)
    ra=A.roi_readout(reference['physical'],aa['adc'],mask)
    independent_mask=G.roi()!=0
    c.equal('ROI_independent_geometric_support',mask,independent_mask)
    independent_b_mean=float(np.mean(bb['adc'][independent_mask]))
    c.expected('ROI',B_mean=independent_b_mean,independent_mask=independent_mask)
    c.near('ROI_A_B_mean',ra['U_mean'],independent_b_mean,1e-10)


def d04(c): encoded(c,[.01]*4,[0.]*4)
def d05(c): encoded(c,[.02]*4,[-5.]*4)
def d06(c): encoded(c,[.01,.02,.03,.04],[0.]*4)


def d07(c):
    base=G.signal_volume()[:,0,0,:2]
    for k in range(4):
        for value in (0.,-1.):
            x=base.copy(); x[k,0]=value
            x=c.fixtures.arrays(f'b{k}_v{value}',signal=x)['signal']
            a,_=c.compare(f'b{k}_v{value}',x)
            c.equal(f'b{k}_v{value}_reason',a['reason'],[1,0])
            c.equal(f'b{k}_v{value}_encoded_zero',a['adc'][0],0.)
            c.near(f'b{k}_v{value}_valid_retained',a['adc'][1],.0012,1e-12)


def d08(c):
    signal=np.stack([np.full(4,20.),20*np.exp(G.BVALS*.0012)],axis=1)
    x=c.fixtures.arrays('nonpositive_fit',signal=signal)['signal']; a,_=c.compare('nonpositive_fit',x,[0.,0.])
    c.equal('reason_fit_nonpositive',a['reason'],[2,2])


def d09(c):
    x=c.fixtures.arrays('high_ADC',signal=1e9*np.exp(-G.BVALS*.015))['signal']
    a,_=c.compare('high_ADC',x,.015); c.equal('high_flag',a['high'],True); c.equal('valid',a['reason'],0)


def d10(c):
    ds=c.dicoms('known_scaling',G.volume(c.id,pixels=np.full(G.SHAPE,1000,np.uint16),rs=.001,ri=.2))
    ref=A.load_volume(ds,G.expected_identity(c.id,'ADC'))
    c.near('scaled_once_and_units',ref['physical'],.0012,1e-12)
    bad=deepcopy(ds)
    for d in bad: d.RescaleType='UNKNOWN'
    bad=c.dicoms('unknown_unit',bad)
    c.expect('unknown_unit',lambda:A.load_volume(bad,G.expected_identity(c.id,'ADC')))
    bad=deepcopy(ds)
    for d in bad:
        rw=Dataset(); rw.RealWorldValueSlope=.7; rw.RealWorldValueIntercept=3.
        code=Dataset(); code.CodeValue='mm2/s'; code.CodingSchemeDesignator='UCUM'; code.CodeMeaning='square millimeters per second'
        rw.MeasurementUnitsCodeSequence=Sequence([code]); d.RealWorldValueMappingSequence=Sequence([rw])
    bad=c.dicoms('conflicting_RWVM',bad)
    c.expect('conflicting_RWVM',lambda:A.load_volume(bad,G.expected_identity(c.id,'ADC')))


def d11(c):
    x=c.fixtures.arrays('denominator',P=np.array([0,1,2,3])*.001,U=np.array([.5,1,2,3])*.001,mask=np.ones(4,bool))
    first=A.roi_readout(x['P'],x['U'],x['mask']); repeat=A.roi_readout(x['U'],x['P'],x['mask'])
    c.equal('fixed_original_denominator_first',first['roi_voxels'],4); c.equal('fixed_original_denominator_repeat',repeat['roi_voxels'],4)
    c.near('first_difference',first['difference_output_units'],-.125,1e-12)
    c.near('repeat_difference',repeat['difference_output_units'],.125,1e-12)
    c.near('patient_mean',np.mean([first['difference_output_units'],repeat['difference_output_units']]),0,1e-12)
    c.near('mean_absolute_acquisition_difference',np.mean(np.abs([first['difference_output_units'],repeat['difference_output_units']])),.125,1e-12)
    c.near('P_mean_includes_zero',first['P_mean'],.0015,1e-12)


def d12(c):
    rng=np.random.Generator(np.random.PCG64(20260923))
    z,y,x=np.indices(G.SHAPE)
    truth=.0008+z*.00003+y*.000001+x*.0000001
    signal=(100+z*3+y*2+x)[None]*np.exp(-G.BVALS[:,None,None,None]*truth[None])
    frozen=c.fixtures.arrays('varying_geometry_signal',signal=signal,analytic=truth,bound=G.quantization_bound(signal,[.01]*4))
    for angle in (0,15):
        ref=c.adc(f'adc_angle{angle}',angle=angle)
        source=c.dicoms(f'trace_angle{angle}',G.trace(c.id,signal=frozen['signal'],angle=angle,variant=f'angle{angle}'))
        for order in ('random','reverse_b'):
            idx=rng.permutation(48) if order=='random' else np.arange(48).reshape(4,12)[::-1].ravel()
            idx=c.fixtures.arrays(f'order_{angle}_{order}',indexes=idx)['indexes']
            ds=[source[i] for i in idx]
            # Misleading instance numbers ensure ordering is derived from tags/geometry.
            for j,d in enumerate(ds): d.InstanceNumber=900-j
            ds=c.dicoms(f'ordered_{angle}_{order}',ds)
            aa=A.trace_signal(ds,ref,G.expected_identity(c.id,'TRACE')); bb=B.from_datasets(ds)
            c.near(f'signal_{angle}_{order}',aa['signal'],bb['signal'],1e-12)
            fitted,_=c.compare(f'fit_{angle}_{order}',aa['signal'])
            c.equal(f'b_sorted_{angle}_{order}',aa['b_values'],G.BVALS)
            error=np.abs(fitted['adc']-frozen['analytic'])
            c.check(f'spatially_varying_ADC_{angle}_{order}',np.all(error<=frozen['bound']),float(error.max()),'per-voxel independent quantization bound')
            c.near(f'positions_{angle}_{order}',aa['positions'],G.positions(),.01)
        mask=A.align(ref,c.mask(f'mask_angle{angle}',angle=angle))
        c.equal(f'geometry_mask_{angle}',mask,G.roi()); c.equal(f'roi_count_{angle}',np.count_nonzero(mask),384)


def d13(c):
    for angle in (0,15):
        ref=c.adc(f'adc{angle}',angle=angle)
        mask=A.align(ref,c.mask(f'mask{angle}',angle=angle))
        ds=c.dicoms(f'fractional_SEG{angle}',G.segmentation(c.id,angle))
        seg=A.load_volume(ds,G.expected_identity(c.id,'SEG'),kind='SEG')
        mapped=A.align(ref,seg)
        c.equal(f'mask_full_support{angle}',mask!=0,G.roi()!=0)
        c.equal(f'seg_full_support{angle}',mapped!=0,G.roi()!=0)
        c.equal(f'MASK_SEG_mismatch{angle}',np.count_nonzero((mapped!=0)!=(mask!=0)),0)
        c.equal(f'SEG_ROI_count{angle}',np.count_nonzero(mapped),384)
        c.equal(f'sparse_frame_count{angle}',int(ds[0].NumberOfFrames),6)


def d14(c):
    ref=c.adc(); original=G.volume(c.id,'MASK',G.roi(),sparse=True,rs=1)
    for tag,value in [('PatientID','SYNTHETIC_WRONG'),('StudyInstanceUID',G.uid(c.id,'WRONG_STUDY')),('ClinicalTrialTimePointID','T1')]:
        ds=deepcopy(original)
        for d in ds: setattr(d,tag,value)
        ds=c.dicoms(tag,ds)
        c.expect(tag,lambda ds=ds:A.load_volume(ds,G.expected_identity(c.id,'MASK'),kind='MASK'),'STOP')
    # Series identity is also explicit in the input contract.
    ds=deepcopy(original)
    for d in ds: d.SeriesInstanceUID=G.uid(c.id,'WRONG_SERIES')
    ds=c.dicoms('wrong_series',ds)
    c.expect('SeriesInstanceUID',lambda:A.load_volume(ds,G.expected_identity(c.id,'MASK'),kind='MASK'),'STOP')
    for variant in ('FOR','translation','orientation','spacing'):
        ds=deepcopy(original)
        for d in ds:
            if variant=='FOR': d.FrameOfReferenceUID=G.uid(c.id,'WRONG_FOR')
            elif variant=='translation': d.ImagePositionPatient=[float(d.ImagePositionPatient[0])+1.,float(d.ImagePositionPatient[1]),float(d.ImagePositionPatient[2])]
            elif variant=='orientation': d.ImageOrientationPatient=[1.,.001,0.,0.,1.,0.]
            else: d.PixelSpacing=[1.251,1.25]
        ds=c.dicoms(variant,ds)
        c.expect(variant,lambda ds=ds:A.align(ref,A.load_volume(ds,G.expected_identity(c.id,'MASK'),kind='MASK')),'STOP' if variant=='FOR' else 'HOLD')


def d15(c):
    ref=c.adc(); original=G.trace(c.id)
    variants={'missing_b600':[d for d in original if float(d.DiffusionBValue)!=600],
              'duplicate_b800':original+deepcopy(original[36:]),
              'missing_single_frame':original[:17]+original[18:],
              'missing_full_slice':[d for d in original if float(d.ImagePositionPatient[2])!=25.],
              'duplicate_slice':original+deepcopy([original[5]])}
    for name,ds in variants.items():
        ds=c.dicoms(name,ds)
        c.expect(name,lambda ds=ds:A.trace_signal(ds,ref,G.expected_identity(c.id,'TRACE')))
    for missing in ('RescaleSlope','RescaleIntercept'):
        ds=G.volume(c.id)
        for d in ds: delattr(d,missing)
        ds=c.dicoms(f'missing_{missing}',ds)
        c.expect(missing,lambda ds=ds:A.load_volume(ds,G.expected_identity(c.id,'ADC')))


    # Bounded decoder regression after systematic TRACE representation mismatch.
    # Original ADC-missing-metadata cases above stay HOLD, unchanged.
    ds=G.trace(c.id,slopes=[1.,1.,1.,1.])
    for item in ds:
        del item.RescaleSlope; del item.RescaleIntercept
    ds=c.dicoms('trace_both_absent_identity',ds)
    aa=A.trace_signal(ds,ref,G.expected_identity(c.id,'TRACE')); bb=B.from_datasets(ds)
    c.equal('TRACE_identity_A_B_signal',aa['signal'],bb['signal'])
    c.equal('TRACE_identity_preserves_stored_values',aa['signal'],aa['raw'])
    c.equal('TRACE_identity_no_explicit_scale_claim',aa['all_public_rescale_explicit'],False)
    c.compare('TRACE_identity_fit',aa['signal'])
    for missing in ('RescaleSlope','RescaleIntercept'):
        broken=G.trace(c.id)
        for item in broken:delattr(item,missing)
        broken=c.dicoms('trace_partial_missing_'+missing,broken)
        c.expect('TRACE_partial_missing_'+missing,lambda broken=broken:A.trace_signal(broken,ref,G.expected_identity(c.id,'TRACE')))
        try:B.from_datasets(broken)
        except ValueError:c.check('B_partial_missing_'+missing,True)
        else:c.check('B_partial_missing_'+missing,False)


def d16(c):
    mask=G.roi()!=0; public=np.full(G.SHAPE,.0012)
    for value,name in [(np.nan,'NaN'),(np.inf,'Inf')]:
        signal=G.signal_volume(); signal[2,3,4,4]=value
        signal=c.fixtures.arrays(f'signal_{name}',signal=signal)['signal']
        a,b=c.compare(f'signal_{name}',signal)
        c.equal(f'{name}_reason',a['reason'][3,4,4],3)
        c.check(f'{name}_not_encoded_zero',not np.isfinite(a['adc'][3,4,4]),a['adc'][3,4,4],'nonfinite')
        c.expect(f'{name}_signal_acquisition_HOLD',lambda a=a:A.roi_readout(public,a['adc'],mask))
        p=public.copy(); p[3,4,4]=value
        p=c.fixtures.arrays(f'public_{name}',public=p)['public']
        c.expect(f'{name}_public_HOLD',lambda p=p:A.roi_readout(p,public,mask))
    p=public.copy(); p[3,4,4]=-.001
    p=c.fixtures.arrays('public_negative',public=p)['public']
    c.expect('negative_public_HOLD',lambda:A.roi_readout(p,public,mask))
    # Nonfinite per-frame rescale must be blocked before any ADC can be usable.
    ref=c.adc()
    for tag in ('RescaleSlope','RescaleIntercept'):
        ds=G.trace(c.id); setattr(ds[17],tag,float('nan')); ds=c.dicoms(f'nonfinite_{tag}',ds)
        c.expect(f'nonfinite_{tag}',lambda ds=ds:A.trace_signal(ds,ref,G.expected_identity(c.id,'TRACE')))


def d17(c):
    source=c.dicoms('source',G.trace(c.id)); known={str(d.SOPInstanceUID) for d in source}
    def referenced(missing=False):
        ds=G.volume(c.id)
        for z,d in enumerate(ds):
            image=Dataset(); image.ReferencedSOPClassUID=source[z].SOPClassUID
            image.ReferencedSOPInstanceUID=G.uid(c.id,'MISSING') if missing else source[z].SOPInstanceUID
            d.SourceImageSequence=Sequence([image])
            study=Dataset(); study.ReferencedSOPClassUID='1.2.840.10008.3.1.2.3.1'; study.ReferencedSOPInstanceUID=G.uid(c.id,'DETACHED_STUDY')
            d.ReferencedStudySequence=Sequence([study])
        return ds
    ds=c.dicoms('closed_image_and_detached',referenced()); result=A.audit_references(ds,known)
    c.equal('resolved_image_count',result['image_reference_count'],12)
    c.equal('detached_study_count',result['study_reference_count'],1)
    c.equal('unresolved_image_count',len(result['unresolved']),0)
    ds=c.dicoms('missing_image',referenced(True))
    c.expect('missing_image_reference_HOLD',lambda:A.audit_references(ds,known))


def d18(c):
    x=c.fixtures.arrays('invalid_roi',positive=np.full(G.SHAPE,.0012),zero=np.zeros(G.SHAPE),mask=G.roi()!=0,empty=np.zeros(G.SHAPE,bool))
    for name,p,u,m in [('empty',x['positive'],x['positive'],x['empty']),('public_all_zero',x['zero'],x['positive'],x['mask']),('reference_all_zero',x['positive'],x['zero'],x['mask'])]:
        c.expect(name,lambda p=p,u=u,m=m:A.roi_readout(p,u,m))


def d19(c):
    rng=np.random.Generator(np.random.PCG64(20260923)); truth=1000*np.exp(-G.BVALS*.0012)[:,None]
    for snr in (10,30,100):
        n1=rng.normal(0,1000/snr,(4,1000)); n2=rng.normal(0,1000/snr,(4,1000))
        signal=np.sqrt((truth+n1)**2+n2**2)
        x=c.fixtures.arrays(f'snr{snr}',signal=signal,n1=n1,n2=n2)['signal']
        a,_=c.compare(f'snr{snr}',x)
        c.check(f'finite_snr{snr}',np.all(np.isfinite(a['adc'])),int(np.isfinite(a['adc']).sum()),1000)
        c.diagnostics[f'snr{snr}']={'mean_ADC':float(np.mean(a['adc'])),'bias_vs_0.0012':float(np.mean(a['adc'])-.0012),'not_an_unbiasedness_acceptance_test':True}


def d20(c):
    counts=[8,7,4,2,2,4,2,1]; sites=np.repeat([f'S{i+1}' for i in range(8)],counts)
    def records(ds):
        return [{'patient_id':f'SYNTHETIC_DRO_{i:02d}','site':str(sites[i-1]),'U_first':.001+.00001*i,
                 'U_repeat':1.1*(.001+.00001*i),'P_first':.001+.00001*i+.001*ds[i-1],
                 'P_repeat':1.1*(.001+.00001*i)+.001*ds[i-1]} for i in range(1,31)]
    const=c.fixtures.json('constant_records',records(np.full(30,.08)))
    trend=c.fixtures.json('trend_records',records(.01*np.arange(1,31)-.155))
    result=ST.summarize(const); pr=result['primary']; c.diagnostics['constant']=result
    c.equal('constant_n',pr['n'],30); c.near('constant_theta',pr['theta'],.08,1e-12); c.near('constant_CI',pr['ci'],[.08,.08],1e-12)
    result=ST.summarize(trend); c.diagnostics['trend']=result
    c.near('trend_theta',result['primary']['theta'],0,1e-12)
    indexes=ST.bootstrap_indices(sites); indexes2=ST.bootstrap_indices(sites)
    independent_rng=np.random.Generator(np.random.PCG64(20260923))
    independent_blocks=[]
    for site in sorted(set(sites)):
        members=np.flatnonzero(sites==site)
        draws=independent_rng.integers(0,len(members),size=(10000,len(members)))
        independent_blocks.append(members[draws])
    independent_indexes=np.concatenate(independent_blocks,axis=1).astype(np.int64)
    c.equal('bootstrap_independent_construction',indexes,independent_indexes)
    c.expected('bootstrap',indexes=independent_indexes)
    c.equal('bootstrap_shape',indexes.shape,(10000,30)); c.check('seed_reproduction',np.array_equal(indexes,indexes2),hashlib.sha256(indexes.tobytes()).hexdigest(),hashlib.sha256(indexes2.tobytes()).hexdigest())
    c.check('whole_patient_index_range',np.issubdtype(indexes.dtype,np.integer) and np.all((indexes>=0)&(indexes<30)),str(indexes.dtype),'integer indices 0..29')
    for site,count in zip(np.unique(sites),counts):
        c.check(f'site_count_{site}',np.all(np.sum(sites[indexes]==site,axis=1)==count),np.unique(np.sum(sites[indexes]==site,axis=1)),count)
    # Reproduce the protocol's patient estimator and bootstrap directly from whole rows.
    rows=np.array([[r['P_first'],r['P_repeat'],r['U_first'],r['U_repeat']] for r in trend])
    diffs=np.mean(rows[:,:2]-rows[:,2:],axis=1)*1000
    independent_boot=np.mean(diffs[independent_indexes],axis=1)
    expected_ci=np.quantile(independent_boot,[.025,.975],method='linear')
    c.expected('statistics',patient_differences=diffs,bootstrap_means=independent_boot,ci=expected_ci)
    c.near('paired_patient_primary_CI',result['primary']['ci'],expected_ci,1e-12)
    small=c.fixtures.json('n23_records',trend[:23]); out=ST.summarize(small)
    c.equal('n23',out['primary']['n'],23); c.check('n23_primary_CI_prohibited',out['primary']['ci'] is None,out['primary']['ci'],None)
    missing=deepcopy(trend); missing[0]['P_repeat']=None; missing[0]['U_repeat']=None
    missing=c.fixtures.json('missing_repeat_records',missing); out=ST.summarize(missing)
    c.equal('missing_pair_not_zero_n',out['primary']['n'],29)
    c.near('missing_pair_excluded_theta',out['primary']['theta'],float(np.mean(diffs[1:])),1e-12)


def d21(c):
    b0=np.concatenate([np.arange(80,86),np.arange(174,180)])
    signal=b0[None,:]*np.exp(-G.BVALS[:,None]*.0012)
    x=c.fixtures.arrays('threshold_signals',b0_integer=b0,signal=signal,slopes=[8.2844932845,17.6351648352])
    fitted,_=c.compare('all_positive_reference',x['signal'],np.full(12,.0012))
    c.equal('reference_no_b0_threshold',np.count_nonzero(fitted['adc']>0),12)
    for j,slope in enumerate(x['slopes']):
        threshold=10*float(slope); pzero=b0<threshold
        p=np.where(pzero,0.,.0012)
        y=c.fixtures.arrays(f'public_threshold{j}',public=p,zero=pzero,mask=np.ones(12,bool))
        out=A.roi_readout(y['public'],fitted['adc'],y['mask'])
        c.equal(f'fixed_denominator{j}',out['roi_voxels'],12)
        c.equal(f'expected_zero_boundary{j}',np.count_nonzero(y['zero']),3 if j==0 else 9)
        c.equal(f'P_U_support_mismatch{j}',np.count_nonzero((y['public']==0)!=(fitted['adc']==0)),3 if j==0 else 9)
        c.near(f'fixed_mean_difference{j}',out['difference_output_units'],-.3 if j==0 else -.9,1e-12)
        audit=A.threshold_audit(x['b0_integer'],y['zero'],y['mask'],float(slope))
        c.diagnostics[f'threshold_audit{j}']=audit
        # Return contract is verified below, with independently counted support.
        c.equal(f'audit_raw10_count{j}',audit['raw10']['predicted_zero_voxels'],int(np.count_nonzero(b0<10)))
        c.equal(f'audit_scaled10_count{j}',audit['raw10_times_source_RS']['predicted_zero_voxels'],int(np.count_nonzero(b0<threshold)))
        c.equal(f'audit_scaled10_mismatch{j}',audit['raw10_times_source_RS']['zero_mismatch_voxels'],0)
        c.equal(f'audit_raw10_mismatch{j}',audit['raw10']['zero_mismatch_voxels'],3 if j==0 else 9)


CASES=[d01,d02,d03,d04,d05,d06,d07,d08,d09,d10,d11,d12,d13,d14,d15,d16,d17,d18,d19,d20,d21]


def main():
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--run',required=True,choices=['run01','run02','run03','recovery01','recovery01_final'])
    args=parser.parse_args(); number=1 if args.run.startswith('recovery01') else int(args.run[-2:])
    if args.run.startswith('recovery01'):
        repair=ROOT/'docs/systemic_repair_plan.json'
        ledger=ROOT/'execution/patient_run_ledger.json'
        if not repair.exists() or not ledger.exists(): raise SystemExit('Documented systemic repair required')
        rr=json.loads(repair.read_text()); ll=json.loads(ledger.read_text())
        if rr.get('recovery_number')!=1 or len(ll)!=1 or ll[0]['state']!='SYSTEMIC_STOP': raise SystemExit('Systemic recovery budget exhausted or invalid state')
    # Prevent execution of uncommitted source and capture the exact committed code.
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    tracked=subprocess.check_output(['git','status','--porcelain','--','src','config'],cwd=ROOT,text=True)
    if tracked.strip(): raise SystemExit('Commit all src/config code before formal DRO execution')
    output=DRO/'results'/args.run
    if output.exists(): raise SystemExit(f'Immutable run already exists: {output}')
    if number>1:
        previous=DRO/'results'/f'run{number-1:02d}'/'summary.json'
        if not previous.exists() or json.loads(previous.read_text())['all_passed']:
            raise SystemExit('Repair run requires preceding failed complete run')
        repair=DRO/'results'/f'repair{number-1:02d}.json'
        if not repair.exists(): raise SystemExit(f'Root must record diagnosed defect and diff in {repair}')
    output.mkdir(parents=True); expected_root=DRO/'expected'/args.run; expected_root.mkdir(parents=True)
    started=dt.datetime.now(dt.timezone.utc).isoformat()
    metadata={'run':args.run,'commit':commit,'started_utc':started,'python':sys.version,'platform':platform.platform(),
              'numpy':np.__version__,'pydicom':pydicom.__version__,'synthetic_only':True,'patient_files_read':0,
              'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'src').glob('*.py'))},
              'config_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'config').glob('*.json'))}}
    write_json(output/'environment.json',metadata)
    results=[]
    for i,func in enumerate(CASES,1):
        cid=f'D{i:02d}'; before=dt.datetime.now(dt.timezone.utc); c=None
        result={'case_id':cid,'status':'FAIL','started_utc':before.isoformat()}
        try:
            c=Case(cid,expected_root); func(c)
        except Exception as exc:
            result['unexpected_exception']={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
        finally:
            if c is not None:
                result['assertions']=c.assertions; result['max_errors']=c.max_errors; result['diagnostics']=c.diagnostics
                result['expected_hashes']=c.expected_hashes
                try: result['input_hashes']=c.fixtures.finish()
                except Exception as exc: result['manifest_error']=str(exc)
                if (c.assertions and all(x['pass'] for x in c.assertions) and 'unexpected_exception' not in result and 'manifest_error' not in result): result['status']='PASS'
            result['elapsed_seconds']=(dt.datetime.now(dt.timezone.utc)-before).total_seconds()
            write_json(output/f'{cid}.json',result); results.append(result)
            print(f'{cid}: {result["status"]}',flush=True)
    all_passed=len(results)==21 and all(r['status']=='PASS' for r in results)
    summary={**metadata,'ended_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'all_passed':all_passed,
             'required_cases':21,'executed_cases':len(results),'passed_cases':sum(r['status']=='PASS' for r in results),
             'failed_cases':[r['case_id'] for r in results if r['status']!='PASS'],
             'result_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(output.glob('D*.json'))}}
    write_json(output/'summary.json',summary)
    with (output/'acceptance.tsv').open('x') as f:
        f.write('case_id\tstatus\tassertions\tfailed_assertions\n')
        for r in results:
            checks=r.get('assertions',[])
            f.write(f'{r["case_id"]}\t{r["status"]}\t{len(checks)}\t{sum(not x["pass"] for x in checks)}\n')
    (output/'acceptance.tsv').chmod(0o444)
    print(json.dumps({'run':args.run,'all_passed':all_passed,'failed_cases':summary['failed_cases']},ensure_ascii=False))
    return 0 if all_passed else 1

if __name__=='__main__':
    sys.exit(main())
