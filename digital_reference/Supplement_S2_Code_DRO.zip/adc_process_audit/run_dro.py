#!/usr/bin/env python3
"""Portable replay of the unchanged 21-case DRO; synthetic files only.

This adapter does not call the original formal-run state machine and cannot
resume patient processing. An output path must not exist. No network is used.
"""
from pathlib import Path
import argparse
import datetime as dt
import hashlib
import json
import platform
import sys
import traceback

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'frozen'))


def source_evidence():
    provenance = json.loads((ROOT / 'core_provenance.json').read_text())
    for name, digest in provenance['byte_identical_files'].items():
        actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        if actual != digest:
            raise ValueError(f'Frozen source/config changed: {name}')
    return provenance


def run(output):
    provenance = source_evidence()
    import numpy as np
    import pydicom
    import dro_suite as suite
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    suite.DRO = output
    results_dir = output / 'results'
    expected_dir = output / 'expected'
    results_dir.mkdir()
    expected_dir.mkdir()
    started = dt.datetime.now(dt.timezone.utc).isoformat()
    metadata = {
        'execution_kind': 'PORTABLE_SYNTHETIC_REPLAY',
        'package_version': provenance['package_version'],
        'frozen_production_commit': provenance['frozen_production_commit'],
        'source_sha256': provenance['byte_identical_files'],
        'adapter_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'started_utc': started, 'python': sys.version, 'platform': platform.platform(),
        'numpy': np.__version__, 'pydicom': pydicom.__version__,
        'pinned_dependencies_match': np.__version__ == '2.3.5' and pydicom.__version__ == '3.0.1',
        'synthetic_only': True, 'patient_files_read': 0,
        'not_a_new_patient_recovery': True,
    }
    suite.write_json(results_dir / 'environment.json', metadata)
    results = []
    for i, fn in enumerate(suite.CASES, 1):
        cid = f'D{i:02d}'
        result = {'case_id': cid, 'status': 'FAIL'}
        case = None
        try:
            case = suite.Case(cid, expected_dir)
            fn(case)
        except Exception as exc:
            result['unexpected_exception'] = {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()}
        if case is not None:
            result.update(assertions=case.assertions, max_errors=case.max_errors,
                          diagnostics=case.diagnostics, expected_hashes=case.expected_hashes)
            try:
                result['input_hashes'] = case.fixtures.finish()
            except Exception as exc:
                result['manifest_error'] = str(exc)
            if (case.assertions and all(x['pass'] for x in case.assertions)
                    and 'unexpected_exception' not in result and 'manifest_error' not in result):
                result['status'] = 'PASS'
        suite.write_json(results_dir / f'{cid}.json', result)
        results.append(result)
        print(f'{cid}: {result["status"]}', flush=True)
    count = sum(len(r.get('assertions', [])) for r in results)
    all_passed = len(results) == 21 and count == 299 and all(r['status'] == 'PASS' for r in results)
    summary = {**metadata, 'ended_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
               'executed_cases': len(results), 'passed_cases': sum(r['status'] == 'PASS' for r in results),
               'assertion_count': count, 'expected_assertion_count': 299, 'all_passed': all_passed,
               'failed_cases': [r['case_id'] for r in results if r['status'] != 'PASS'],
               'result_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(results_dir.glob('D*.json'))}}
    suite.write_json(results_dir / 'summary.json', summary)
    with (results_dir / 'acceptance.tsv').open('x') as f:
        f.write('case_id\tstatus\tassertions\tfailed_assertions\n')
        for result in results:
            checks = result.get('assertions', [])
            f.write(f"{result['case_id']}\t{result['status']}\t{len(checks)}\t{sum(not c['pass'] for c in checks)}\n")
    print(json.dumps({'all_passed': all_passed, 'cases': len(results), 'assertions': count}))
    return 0 if all_passed else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, help='New directory for generated fixtures and results')
    args = parser.parse_args()
    try:
        return run(args.output)
    except (FileExistsError, ValueError, OSError) as exc:
        print(f'Cannot run: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
