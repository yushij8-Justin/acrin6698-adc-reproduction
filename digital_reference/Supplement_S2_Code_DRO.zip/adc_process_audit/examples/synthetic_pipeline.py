#!/usr/bin/env python3
"""Small end-to-end example: synthetic classic MR/SEG -> ADC -> fixed ROI.

No patient data or input directory is accepted. This is an API demonstration,
not a general clinical DICOM ingestion program or additional validation cohort.
"""
from pathlib import Path
import argparse
import json
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'frozen'))
from run_dro import source_evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    source_evidence()
    import numpy as np
    import adc_core as a
    import dro_generate as g
    import reference_b as b
    from pydicom.dataset import Dataset
    from pydicom.sequence import Sequence
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    fixtures = g.Fixtures(out / 'inputs', 'EXAMPLE')
    identity = lambda role: g.expected_identity('EXAMPLE', role)
    trace = fixtures.dicoms('TRACE', g.trace('EXAMPLE'))
    adcs = g.volume('EXAMPLE')
    for z, ds in enumerate(adcs):
        ref = Dataset()
        ref.ReferencedSOPClassUID = trace[z].SOPClassUID
        ref.ReferencedSOPInstanceUID = trace[z].SOPInstanceUID
        ds.SourceImageSequence = Sequence([ref])
    adc = fixtures.dicoms('ADC', adcs)
    masks = fixtures.dicoms('MASK', g.volume('EXAMPLE', 'MASK', g.roi(), sparse=True, rs=1))
    segs = fixtures.dicoms('SEG', g.segmentation('EXAMPLE'))
    volume = a.load_volume(adc, identity('ADC'), 'ADC')
    mask = a.align(volume, a.load_volume(masks, identity('MASK'), 'MASK')) != 0
    seg = a.align(volume, a.load_volume(segs, identity('SEG'), 'SEG')) != 0
    a.require(np.array_equal(mask, seg), 'MASK_SEG_SUPPORT_MISMATCH')
    known = {str(ds.SOPInstanceUID) for ds in adc + masks + segs + trace}
    references = a.audit_references(adc + masks + segs + trace, known)
    decoded = a.trace_signal(trace, volume, identity('TRACE'))
    reference = a.fit(decoded['signal'])
    independent = b.fit(b.from_datasets(trace)['signal'])
    error = float(np.max(np.abs(reference['adc'][mask] - independent['adc'][mask])))
    if error > 1e-10:
        raise RuntimeError('Independent solver tolerance exceeded')
    readout = a.roi_readout(volume['physical'], reference['adc'], mask)
    np.savez_compressed(out / 'synthetic_arrays.npz',
        public_adc_mm2_s=volume['physical'], reference_adc_mm2_s=reference['adc'], mask=mask, reason=reference['reason'])
    report = {'scope': 'SYNTHETIC_ONLY_NOT_A_PATIENT_RESULT', 'status': 'PASS',
              'public_roi_mean_unit': 'mm2/s', 'difference_unit': '10^-3 mm2/s',
              'references': references, 'readout': readout, 'independent_max_error_mm2_s': error,
              'input_sha256': fixtures.finish()}
    (out / 'report.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({'status': 'PASS', 'roi_voxels': readout['roi_voxels'], 'P_mean_mm2_s': readout['P_mean'], 'U_mean_mm2_s': readout['U_mean']}))


if __name__ == '__main__':
    main()
