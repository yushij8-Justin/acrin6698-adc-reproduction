# API与单位合同

在项目中显式将`frozen/`加入Python模块搜索路径后导入对应模块。这里的函数名、参数及输出对应冻结代码；不保证为一般临床DICOM接口。

## 数组计算

```python
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path("frozen").resolve()))
from adc_core import fit, roi_readout

b = np.array([0, 100, 600, 800], dtype=float)
signal = 200.0 * np.exp(-b[:, None] * np.array([0.0012, 0.0020])[None, :])
result = fit(signal)
public = np.array([0.0, 0.0020])  # Synthetic constructed comparator, mm²/s.
readout = roi_readout(public, result["adc"], np.array([True, True]))
print(readout)
```

`fit(signal, b_values)`输入形状为`(4, ...)`，b值顺序固定0、100、600、800 s/mm²。对数回归含截距、无权重，内部float64；信号幅度不是ADC单位。输出`adc`为mm²/s，形状为`(...)`；`reason`与`high`同形。

|reason|含义|ADC输出|
|---|---|---|
|0|有限正信号且拟合ADC>10⁻¹² mm²/s|原拟合值|
|1|至少一个有限信号≤0，所有输入均有限|编码0|
|2|有限拟合ADC≤10⁻¹² mm²/s|编码0|
|3|非有限输入或拟合|NaN，进入ROI时须HOLD|

`high`只标记ADC>0.01 mm²/s，不删除或截断。编码零不表示真实零扩散。NaN不能静默替换为零。

`roi_readout(P, U, mask)`要求三个数组同形，P/U单位均为mm²/s；分母为原mask全部True体素。空mask、非有限值、负ADC、P全零或U全零触发GateError。输出`P_mean`与`U_mean`仍为mm²/s；只有`difference_output_units = 1000*(P_mean-U_mean)`的单位为10⁻³ mm²/s。共同正值均值是敏感性描述，不替换主值。

## DICOM组件

- `load_volume(datasets, expected, kind='ADC')`：expected包含patient_id、study_uid、series_uid和visit，必须来自预先核实的清单，不应从同一输入文件自我推导后称身份验证成功。
- `align(reference, moving, full=False)`：按原物理坐标映射；稀疏MASK可补零层；不配准或插值。MASK必须二值；SEG只验证非零支持，不能据此声称概率标定或多分段处理能力。
- `trace_signal(datasets, adc_volume, expected)`：读取固定四b值TRACE并逐帧应用公共变换；同时缺RS/RI且无其他映射的经典MR保留存储值，绝不据此推断原扫描仪的物理信号标定。
- `audit_references(datasets, known_sop_uids)`：检查递归SOP引用是否在给定对象范围内。已显式分开Detached Study Management；**未完整分类所有非图像SOP**。MPPS等可能落入原始未闭合列表，因此该列表不能直接标为“所有缺失MR图像”。原研究通过另外的引用类型核查才确定真正MR缺失。

位置容差0.01 mm；方向和间距容差10⁻⁵。ADC已知单位仅接受代码中规定的`mm2/s`或`10^-3 mm2/s`及其有限格式归一化；未覆盖DICOM Parametric Map、任意单位字符串、任意压缩解码器或所有增强MR表示方式。

`GateError.code`提供具体原因，`status`为HOLD或STOP。原固定患者编排器对ADC单位/映射等系统性问题另有停批升级规则；本包保留的是组件，未包含新的临床批处理放行机制。真实数据的批次处置不能仅根据单一组件的status自动决定。

## 独立B实现

`reference_b.fit()`以独立`numpy.linalg.lstsq`拟合；`from_datasets()`独立解码经典单帧MR TRACE并按b值和物理坐标排序。B数值一致用来检验A的实现，B仍依赖同一组模型假设，不是真值替代物。

## 统计组件

`statistics_core.summarize(records)`接受列表，每条记录包含`patient_id`、`site`和以mm²/s表示的`P_first`、`P_repeat`、`U_first`、`U_repeat`。缺失用None表示，不能填0。身份重复拒绝；只对完整配对患者计算主要估计。

患者差异为两次P−U的均值乘1000，随后患者等权平均。n<24时区间字段为None；不会因ROIs或体素很多而增加患者n。wCV使用同一完整患者集合；非正ROI均值不会被静默筛成新的正值子集。按中心整患者重抽样的种子为20260923，10000次，各区间复用同一索引。

本包只支持原估计合同；不引入ICC挑选、临床阈值优化、删零分析替代、插补或预测模型。
