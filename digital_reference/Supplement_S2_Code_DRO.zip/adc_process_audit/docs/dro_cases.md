# DRO Case Catalogue

The unchanged 21 cases contain 299 acceptance assertions. The original config retains NOT_RUN template fields; current evidence is in evidence/summary.json.

|Case|Constructed input|Acceptance rule|Assertions|Replay|
|---|---|---|---:|---|
|D01|18种无噪声解析组合|ADC真值、斜率符号、mm²/s单位、浮点零规则|7|PASS|
|D02|原信号乘[0.1,1,17.6351648352,100]|共同强度缩放不改变参照ADC；不意外引入固定幅度阈值|24|PASS|
|D03|A闭式OLS与B独立最小二乘|全部无噪声组合差≤1e-10，生产函数不用于生成期望值|6|PASS|
|D04|uint16量化、公共RS=0.01/RI=0|解码后A/B一致；相对解析真值在量化界内|9|PASS|
|D05|RS=0.02、RI=−5|截距应用一次；重复缩放或漏截距应被测试发现|9|PASS|
|D06|b依赖RS=[0.01,0.02,0.03,0.04]|逐帧解码后再拟合；不能取第一帧RS代替全部|9|PASS|
|D07|在已知信号中逐一插入0和负值|U编码0及NONPOSITIVE_SIGNAL；其他有效体素不丢失|56|PASS|
|D08|常量信号及S0×exp(+b×0.0012)|数值零与负拟合编码为0，原因标志正确|6|PASS|
|D09|a=0.015、S0=10^9浮点信号|保留高ADC并提醒，不套用0.01截断；仅浮点算例避免uint16溢出|7|PASS|
|D10|公共ADC原像素1000，RS=0.001、RI=0.2、单位10^-3 mm²/s|应为0.0012 mm²/s；未知单位及额外冲突RWVM为预期HOLD|3|PASS|
|D11|四体素P=[0,1,2,3]、U=[0.5,1,2,3]×10^-3；另一采集交换P与U数组|固定四体素分母，第一采集差−0.125；两采集平均0，绝对差0.125；敏感性不得替换主值|7|PASS|
|D12|文件随机顺序、b值顺序反转、轴位/正确斜位几何|根据标签/坐标还原，不能按ZIP顺序或InstanceNumber猜；ROI384体素|36|PASS|
|D13|6层稀疏MRI MASK；FRACTIONAL SEG原值0/1、MaximumFractionalValue=255|空层补0，非零支持一致；不能按0.5概率阈值清空ROI|10|PASS|
|D14|分别置换患者、Study、访视、FOR；平移1 mm；方向或间距扰动0.001|分别得到身份STOP或几何HOLD，不发生“最近层强行对应”|8|PASS|
|D15|分别缺b600、重复b800、缺层、重复层、缺公共缩放元数据|不猜补、不插值；按合同HOLD|18|PASS|
|D16|ROI内NaN/Inf信号、非有限公开ADC或负公开ADC|采集HOLD；不把未知数据编码成0；与D07有限非正信号区分|19|PASS|
|D17|可闭合图像源SOP、检查级Detached Study引用、缺失图像源SOP|识别非图像引用；真实缺失图像来源必须待查/HOLD，不能误报通过|4|PASS|
|D18|空ROI、公开ADC全零ROI、参考U全零ROI|采集HOLD，均值NA；不能当作零差异成功|3|PASS|
|D19|三档固定Rician噪声|A/B数值及标志一致；仅记录噪声偏差，不以接近真值改变算法|15|PASS|
|D20|30个合成患者、8个中心，构成[8,7,4,2,2,4,2,1]；两流程两采集绑定|完整患者单位重抽、中心样本数保持、种子复跑一致；常量d=0.08应theta=0.08、区间同点；d_i=0.01i−0.155(i=1..30)应theta=0；n=23禁主区间；缺失不当0|21|PASS|
|D21|构造b0整数80—85及174—179，以10×[8.2844932845,17.6351648352]编码公开零支持|两个阈值边界及不一致计数正确；参照U不因此加掩膜，不把构造规律当临床证据|22|PASS|
